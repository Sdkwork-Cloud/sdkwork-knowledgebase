import React, { useState, useEffect } from 'react';
import { Bold, Italic, Strikethrough, List, ListOrdered, Undo, Redo, Code, Columns, FileDown, Sparkles, ChevronDown } from 'lucide-react';
import { InsertToolsMenu, DropdownItem, DropdownDivider, InsertToolItem } from './InsertToolsMenu';

export interface UniversalToolbarGroup {
  type: 'typography' | 'format' | 'list' | 'insert' | 'history' | 'view' | 'export';
  tools?: InsertToolItem[]; // specific to 'insert' type or custom dropdowns
}

export interface UniversalToolbarProps {
  editor: any;
  t: (key: string) => string;
  config: UniversalToolbarGroup[];
  height?: number | string;

  // External handlers
  handleToggleSourceMode?: () => void;
  isSourceMode?: boolean;
  isSplitMode?: boolean;
  setIsSplitMode?: (val: boolean) => void;
  handleExportWord?: () => void;
  handleExportPdf?: () => void;
  handleExportMarkdown?: () => void;
  handleExportImage?: () => void;
}

export function UniversalToolbar({
  editor, t, config = [], height = 40,
  handleToggleSourceMode, isSourceMode, isSplitMode, setIsSplitMode, handleExportWord,
  handleExportPdf, handleExportMarkdown, handleExportImage
}: UniversalToolbarProps) {
  if (!editor) return null;

  const [isExportOpen, setIsExportOpen] = useState(false);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.export-dropdown-container')) {
        setIsExportOpen(false);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  return (
    <div 
      className="flex items-center flex-nowrap gap-1 md:gap-1 text-[var(--color-kb-text-muted)] w-full select-none overflow-visible shrink-0" 
      style={{ minHeight: typeof height === 'number' ? `${height}px` : height, height: typeof height === 'number' ? `${height}px` : height }}
    >
      {config.map((group, idx) => {
        const isLast = idx === config.length - 1;
        
        let content = null;
        switch(group.type) {
          case 'typography':
            content = (
              <select 
                value={
                  editor.isActive('heading', { level: 1 }) ? 'heading1' : 
                  editor.isActive('heading', { level: 2 }) ? 'heading2' : 
                  editor.isActive('heading', { level: 3 }) ? 'heading3' : 
                  editor.isActive('heading', { level: 4 }) ? 'heading4' : 
                  editor.isActive('heading', { level: 5 }) ? 'heading5' : 
                  editor.isActive('heading', { level: 6 }) ? 'heading6' : 
                  editor.isActive('blockquote') ? 'blockquote' : 
                  editor.isActive('codeBlock') ? 'codeblock' : 'body'
                }
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === 'body') editor.chain().focus().setParagraph().run();
                  else if (val === 'heading1') editor.chain().focus().toggleHeading({ level: 1 }).run();
                  else if (val === 'heading2') editor.chain().focus().toggleHeading({ level: 2 }).run();
                  else if (val === 'heading3') editor.chain().focus().toggleHeading({ level: 3 }).run();
                  else if (val === 'heading4') editor.chain().focus().toggleHeading({ level: 4 }).run();
                  else if (val === 'heading5') editor.chain().focus().toggleHeading({ level: 5 }).run();
                  else if (val === 'heading6') editor.chain().focus().toggleHeading({ level: 6 }).run();
                  else if (val === 'blockquote') editor.chain().focus().toggleBlockquote().run();
                  else if (val === 'codeblock') editor.chain().focus().toggleCodeBlock().run();
                }}
                className="bg-white dark:bg-[var(--color-kb-editor)] border border-[var(--color-kb-panel-border)]/70 text-[11.5px] md:text-[13px] text-[var(--color-kb-text)] rounded-md px-1 md:px-2 py-0.5 md:py-1 outline-none cursor-pointer focus:ring-1 focus:ring-[var(--color-kb-accent)] hover:text-[var(--color-kb-text-heading)] transition font-medium mr-1"
              >
                <option value="body">{t('body') || '正文'}</option>
                <option value="heading1">{t('heading1') || '标题 1'}</option>
                <option value="heading2">{t('heading2') || '标题 2'}</option>
                <option value="heading3">{t('heading3') || '标题 3'}</option>
                <option value="heading4">{t('heading4') || '标题 4'}</option>
                <option value="heading5">{t('heading5') || '标题 5'}</option>
                <option value="heading6">{t('heading6') || '标题 6'}</option>
                <option value="blockquote">{t('blockquote') || '引用块'}</option>
                <option value="codeblock">{t('codeblock') || '代码块'}</option>
              </select>
            );
            break;
          case 'format':
            content = (
              <div className="flex items-center gap-0.5">
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().toggleBold().run()} 
                  className={`p-1 md:p-1.5 rounded transition ${editor.isActive('bold') ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-accent)] font-semibold' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`}
                  title="加粗"
                >
                  <Bold size={14} />
                </button>
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().toggleItalic().run()} 
                  className={`p-1 md:p-1.5 rounded transition ${editor.isActive('italic') ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-accent)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`}
                  title="斜体"
                >
                  <Italic size={14} />
                </button>
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().toggleStrike().run()} 
                  className={`p-1 md:p-1.5 rounded transition ${editor.isActive('strike') ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-text-heading)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`}
                  title="删除线"
                >
                  <Strikethrough size={14} />
                </button>
              </div>
            );
            break;
          case 'list':
            content = (
              <div className="flex items-center gap-0.5">
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().toggleBulletList().run()} 
                  className={`p-1 md:p-1.5 rounded transition ${editor.isActive('bulletList') ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-text-heading)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`}
                  title="无序列表"
                >
                  <List size={14}/>
                </button>
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().toggleOrderedList().run()} 
                  className={`p-1 md:p-1.5 rounded transition ${editor.isActive('orderedList') ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-text-heading)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`}
                  title="有序列表"
                >
                  <ListOrdered size={14} />
                </button>
              </div>
            );
            break;
          case 'insert':
            content = group.tools ? <InsertToolsMenu tools={group.tools} /> : null;
            break;
          case 'history':
            content = (
              <div className="flex items-center gap-0.5">
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().undo().run()} 
                  disabled={!editor.can().undo()} 
                  className="p-1 md:p-1.5 rounded transition hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)] disabled:opacity-35 disabled:cursor-not-allowed"
                  title="撤销"
                >
                  <Undo size={14}/>
                </button>
                <button 
                  type="button"
                  onClick={() => editor.chain().focus().redo().run()} 
                  disabled={!editor.can().redo()} 
                  className="p-1 md:p-1.5 rounded transition hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)] disabled:opacity-35 disabled:cursor-not-allowed"
                  title="重做"
                >
                  <Redo size={14}/>
                </button>
              </div>
            );
            break;
          case 'view':
            content = (
              <div className="flex items-center gap-0.5">
                {handleToggleSourceMode && (
                  <button 
                    type="button"
                    onClick={handleToggleSourceMode} 
                    className={`p-1 md:p-1.5 rounded transition ${isSourceMode && !isSplitMode ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-text-heading)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`} 
                    title="查看源码"
                  >
                    <Code size={14} />
                  </button>
                )}
                {setIsSplitMode && (
                  <button 
                    type="button"
                    onClick={() => setIsSplitMode(!isSplitMode)} 
                    className={`p-1 md:p-1.5 rounded transition ${isSplitMode ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-text-heading)]' : 'hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'}`} 
                    title="分屏预览"
                  >
                    <Columns size={14} />
                  </button>
                )}
              </div>
            );
            break;
          case 'export':
            content = (
              <div className="relative ml-auto shrink-0 export-dropdown-container z-30">
                <button 
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsExportOpen(!isExportOpen);
                  }} 
                  className={`p-1 md:p-1.5 px-2.5 py-1 md:px-2.5 md:py-1 rounded-md transition-all flex items-center gap-1 font-semibold text-[11.5px] border border-zinc-200/80 dark:border-zinc-800/80 shadow-[0_1px_2px_rgba(0,0,0,0.02)] ${
                    isExportOpen 
                      ? 'bg-[var(--color-kb-panel-active)] text-[var(--color-kb-accent)]' 
                      : 'bg-white dark:bg-[var(--color-kb-panel)] text-[var(--color-kb-text)] hover:bg-[var(--color-kb-panel-hover)] hover:text-[var(--color-kb-text-heading)]'
                  }`} 
                  title="导出选项"
                >
                  <FileDown size={13} className="opacity-80" />
                  <span className="whitespace-nowrap">导出</span>
                  <ChevronDown size={11} className={`opacity-60 transition-transform duration-200 ${isExportOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isExportOpen && (
                  <div className="absolute right-0 top-[28px] md:top-[32px] bg-white dark:bg-[var(--color-kb-editor)] border border-zinc-200/80 dark:border-[var(--color-kb-panel-border)] shadow-[0_4px_16px_rgba(0,0,0,0.08)] dark:shadow-[0_4px_24px_rgba(0,0,0,0.4)] rounded-xl py-1 min-w-[145px] z-[310] animate-in fade-in slide-in-from-top-2 duration-150">
                    <DropdownItem 
                      text="导出为 PDF" 
                      icon={
                        <span className="w-9 h-5 bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 text-[10px] font-bold rounded flex items-center justify-center border border-rose-100 dark:border-rose-900/40">
                          PDF
                        </span>
                      }
                      onClick={() => {
                        setIsExportOpen(false);
                        handleExportPdf?.();
                      }}
                    />
                    <DropdownItem 
                      text="导出为 Markdown" 
                      icon={
                        <span className="w-9 h-5 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 text-[10px] font-bold rounded flex items-center justify-center border border-emerald-100 dark:border-emerald-900/40">
                          MD
                        </span>
                      }
                      onClick={() => {
                        setIsExportOpen(false);
                        handleExportMarkdown?.();
                      }}
                    />
                    <DropdownItem 
                      text="导出为 Word" 
                      icon={
                        <span className="w-9 h-5 bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 text-[10px] font-bold rounded flex items-center justify-center border border-blue-100 dark:border-blue-900/40">
                          DOC
                        </span>
                      }
                      onClick={() => {
                        setIsExportOpen(false);
                        handleExportWord?.();
                      }}
                    />
                    <DropdownItem 
                      text="导出为 图片" 
                      icon={
                        <span className="w-9 h-5 bg-orange-50 text-orange-600 dark:bg-orange-950/40 dark:text-orange-400 text-[10px] font-bold rounded flex items-center justify-center border border-orange-100 dark:border-orange-900/40">
                          PNG
                        </span>
                      }
                      onClick={() => {
                        setIsExportOpen(false);
                        handleExportImage?.();
                      }}
                    />
                  </div>
                )}
              </div>
            );
            break;
          default:
            return null;
        }

        return (
          <React.Fragment key={idx}>
            {content}
            {!isLast && content && (
              <span className="w-px h-3.5 bg-[var(--color-kb-panel-border)] mx-1"></span>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}
