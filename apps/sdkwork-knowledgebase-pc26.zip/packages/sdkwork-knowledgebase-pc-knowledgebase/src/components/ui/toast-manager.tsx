import React, { useState, useEffect } from 'react';

export interface ToastConfig {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

class ToastManager {
  private listener: ((toasts: ToastConfig[]) => void) | null = null;
  private toasts: ToastConfig[] = [];

  subscribe(listener: (toasts: ToastConfig[]) => void) {
    this.listener = listener;
    listener(this.toasts);
    return () => {
      this.listener = null;
    };
  }

  show(message: string, type: 'success' | 'error' | 'info' = 'info', duration: number = 3000) {
    const id = Math.random().toString(36).substring(2, 9);
    const toast: ToastConfig = { id, message, type, duration };
    this.toasts = [...this.toasts, toast];
    if (this.listener) {
      this.listener(this.toasts);
    }

    setTimeout(() => {
      this.remove(id);
    }, duration);
  }

  remove(id: string) {
    this.toasts = this.toasts.filter(t => t.id !== id);
    if (this.listener) {
      this.listener(this.toasts);
    }
  }
}

export const toastManager = new ToastManager();

export const toast = {
  success: (msg: string, duration?: number) => toastManager.show(msg, 'success', duration),
  error: (msg: string, duration?: number) => toastManager.show(msg, 'error', duration),
  info: (msg: string, duration?: number) => toastManager.show(msg, 'info', duration),
};

export function ToastContainer() {
  const [toasts, setToasts] = useState<ToastConfig[]>([]);

  useEffect(() => {
    return toastManager.subscribe(setToasts);
  }, []);

  return (
    <div className="fixed top-8 left-1/2 transform -translate-x-1/2 z-[10000] flex flex-col items-center gap-2 pointer-events-none">
      {toasts.map(t => (
        <div 
          key={t.id} 
          className={`px-4 py-2.5 rounded-xl shadow-lg border text-sm font-medium flex items-center transition-all animate-in fade-in slide-in-from-top-4 pointer-events-auto ${
            t.type === 'success' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
            t.type === 'error' ? 'bg-red-50 text-red-700 border-red-200' :
            'bg-zinc-900 text-zinc-100 border-zinc-800'
          }`}
        >
          {t.type === 'success' && <span className="mr-2">🎉</span>}
          {t.type === 'error' && <span className="mr-2">🚨</span>}
          {t.type === 'info' && <span className="mr-2">ℹ️</span>}
          {t.message}
        </div>
      ))}
    </div>
  );
}
