import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, PlayCircle, Image as ImageIcon, Video, Mic, Box, Link2, Paperclip, Plus } from 'lucide-react';

export interface InsertToolItem {
  name: string;
  hasDropdown: boolean;
  onClick: () => void;
  dropdownContent?: React.ReactNode;
}

export interface InsertToolsMenuProps {
  tools: InsertToolItem[];
}

export function InsertToolsMenu({ tools }: InsertToolsMenuProps) {
  const [openMenuName, setOpenMenuName] = useState<string | null>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.insert-tool-item-container')) {
        setOpenMenuName(null);
      }
    };
    document.addEventListener('click', handleOutsideClick);
    return () => document.removeEventListener('click', handleOutsideClick);
  }, []);

  return (
    <div className="flex items-center gap-1.5 md:gap-1.5 ml-0 md:ml-1 shrink-0">
      {tools.map((tool, idx) => {
        const isOpen = openMenuName === tool.name;

        return (
          <div className="insert-tool-item-container relative overflow-visible shrink-0" key={idx}>
            <button
              type="button"
              onClick={() => {
                if (tool.hasDropdown) {
                  setOpenMenuName(isOpen ? null : tool.name);
                } else {
                  setOpenMenuName(null);
                  tool.onClick();
                }
              }}
              className={`cursor-pointer transition-all font-semibold text-[10.5px] md:text-[11.5px] px-1 md:px-2 py-1 rounded-md flex items-center gap-0.5 select-none shrink-0 ${
                isOpen
                  ? 'text-[#07c160] dark:text-[#07c160] bg-[var(--color-kb-panel-hover)]'
                  : 'text-[var(--color-kb-text-muted)] hover:text-[#07c160] dark:hover:text-[#07c160] hover:bg-[var(--color-kb-panel-hover)]'
              }`}
            >
              <span className="whitespace-nowrap">{tool.name}</span>
              {tool.hasDropdown && (
                <span className="text-[9px] opacity-75 font-normal ml-[0.5px] shrink-0">▾</span>
              )}
            </button>

            {tool.hasDropdown && isOpen && (
              <div 
                 className="absolute top-[34px] left-1/2 -translate-x-1/2 bg-[var(--color-kb-editor)] border border-[var(--color-kb-panel-border)] shadow-[0_6px_24px_rgba(0,0,0,0.12)] rounded-xl py-1.5 min-w-[145px] z-[250] animate-in fade-in slide-in-from-top-2 duration-150 before:content-[''] before:absolute before:-top-1.5 before:left-[calc(50%-5px)] before:w-2.5 before:h-2.5 before:bg-[var(--color-kb-editor)] before:rotate-45 before:border-l before:border-t before:border-[var(--color-kb-panel-border)]"
                 onClick={() => setOpenMenuName(null)} // Close on item click
              >
                {tool.dropdownContent}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// Reusable dropdown item
export function DropdownItem({ onClick, icon, text, disabled, highlighted }: { onClick: () => void, icon?: React.ReactNode, text: string, disabled?: boolean, highlighted?: boolean }) {
  return (
    <div 
      onClick={(e) => {
        if (!disabled) {
          onClick();
        } else {
          e.stopPropagation();
        }
      }}
      className={`px-4 py-2 text-xs flex items-center gap-2 transition-colors w-full text-left relative z-10 ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-[var(--color-kb-panel-hover)]'
      } ${
        highlighted ? 'text-[var(--color-kb-accent)] font-bold' : 'text-[var(--color-kb-text)] font-semibold'
      }`}
    >
      {icon}
      <span>{text}</span>
    </div>
  );
}

export function DropdownDivider() {
  return <div className="h-[1px] bg-[var(--color-kb-panel-border)] my-1 relative z-10"></div>;
}
