import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import { Extension } from '@tiptap/core';
import Placeholder from '@tiptap/extension-placeholder';
import { BubbleMenu } from '@tiptap/react/menus';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import { Markdown } from 'tiptap-markdown';
import { Bot, Bold, Italic, Strikethrough, Heading1, Heading2, Heading3, List, ListOrdered, Undo, Redo, Sparkles, Languages, CheckCheck, PenTool, Type, FileType2, ChevronDown, Wand2, FilePlus2, Lightbulb, Image as ImageIcon, Video, Box, Code } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { WechatAppletModal } from './components/WechatAppletModal';
import { UniversalToolbar, UniversalToolbarGroup } from './components/UniversalToolbar';
import { DropdownItem, DropdownDivider } from './components/InsertToolsMenu';
import { WechatMiniprogram } from './extensions/WechatMiniprogram';
import { Audio } from './extensions/Audio';
import { Video as VideoExtension } from './extensions/Video';
import { EditorBubbleMenu } from './EditorBubbleMenu';
import { AIService } from './services/ai';
import { toast } from './components/ui/toast-manager';

export interface TiptapEditorProps {
  initialContent: string;
  mode?: 'richtext' | 'markdown';
  onChange?: (content: string) => void;
  onEditorReady?: (editor: any) => void;
  docTitle?: string;
  onTitleChange?: (title: string) => void;
  hideTitle?: boolean;
  onOpenImageGallery?: () => void;
  onWechatScan?: () => void;
  onOpenAiImage?: () => void;
  onAudioInsert?: () => void;
  onAudioGallery?: () => void;
  onVideoGallery?: () => void;
  toolbarConfig?: UniversalToolbarGroup[];
}

const StyleGlobalExtension = Extension.create({
  name: 'styleGlobal',
  addGlobalAttributes() {
    return [
      {
        types: [
          'heading', 'paragraph', 'blockquote', 'listItem', 'bulletList', 'orderedList', 'image',
          'bold', 'italic', 'strike'
        ],
        attributes: {
          style: {
            default: null,
            parseHTML: element => element.getAttribute('style'),
            renderHTML: attributes => {
              if (!attributes.style) {
                return {}
              }
              return { style: attributes.style }
            }
          }
        }
      }
    ];
  }
});

export function TiptapEditor({ 
  initialContent, mode = 'richtext', onChange, onEditorReady, docTitle = '', onTitleChange, hideTitle = false,
  onOpenImageGallery, onWechatScan, onOpenAiImage, onAudioInsert, onAudioGallery, onVideoGallery, toolbarConfig
}: TiptapEditorProps) {
  const { t } = useTranslation('editor');
  const [title, setTitle] = useState(docTitle);

  useEffect(() => {
    setTitle(docTitle);
  }, [docTitle]);

  const handleTitleChangeLocal = (newTitle: string) => {
    setTitle(newTitle);
    onTitleChange?.(newTitle);
  };
  const [aiLoading, setAiLoading] = useState(false);
  const [isWechatAppletModalOpen, setIsWechatAppletModalOpen] = useState(false);
  const [isSourceMode, setIsSourceMode] = useState(false);
  const [isSplitMode, setIsSplitMode] = useState(false);
  const [sourceCode, setSourceCode] = useState(initialContent);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const editorRef = useRef<any>(null);

  const uploadImage = async (file: File): Promise<string | null> => {
    // Mock the upload with a local object URL to satisfy the logic loop without a server backend
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(URL.createObjectURL(file));
      }, 500);
    });
  };

  const handleImageFiles = async (files: FileList | null | undefined, curEditor: any) => {
    if (!files) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        const url = await uploadImage(file);
        if (url) {
          curEditor.chain().focus().setImage({ src: url }).run();
        }
      }
    }
  };

  const extensions = [
    StarterKit,
    StyleGlobalExtension,
    WechatMiniprogram,
    Audio,
    VideoExtension,
    Placeholder.configure({
      placeholder: t('placeholderText', { defaultValue: '请输入正文或开始创作...' })
    }),
    Image.configure({
       HTMLAttributes: {
         class: 'rounded-lg max-w-full my-4 border border-[var(--color-kb-panel-border)] shadow-sm'
       }
    })
  ];
  
  if (mode === 'markdown') {
    extensions.push(Markdown);
  }

  const editor = useEditor({
    extensions,
    content: initialContent,
    editorProps: {
      attributes: {
        class: 'tiptap-editor outline-none focus:outline-none w-full min-h-[400px]',
      },
      handleDrop: (view, event, slice, moved) => {
        if (!moved && event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length > 0) {
          event.preventDefault();
          if (editorRef.current) {
            handleImageFiles(event.dataTransfer.files, editorRef.current);
          }
          return true;
        }
        return false;
      },
      handlePaste: (view, event, slice) => {
        if (event.clipboardData && event.clipboardData.files && event.clipboardData.files.length > 0) {
          event.preventDefault();
          if (editorRef.current) {
            handleImageFiles(event.clipboardData.files, editorRef.current);
          }
          return true;
        }
        return false;
      }
    },
    onUpdate: ({ editor }) => {
      const data = mode === 'markdown' ? (editor.storage as any).markdown.getMarkdown() : editor.getHTML();
      onChange?.(data);
      if (document.activeElement?.tagName !== 'TEXTAREA') {
         setSourceCode(data);
      }
    }
  });

  editorRef.current = editor;

  useEffect(() => {
    if (editor && onEditorReady) {
      onEditorReady(editor);
    }
    return () => {
      if (onEditorReady) {
        onEditorReady(null);
      }
    };
  }, [editor, onEditorReady]);

  const handleToggleSourceMode = () => {
    // If we transition out of source mode, update the editor
    if (isSourceMode && !isSplitMode) {
      if (editor) {
        editor.commands.setContent(sourceCode);
        onChange?.(sourceCode);
      }
    } else {
      if (editor) {
        const data = mode === 'markdown' ? (editor.storage as any).markdown.getMarkdown() : editor.getHTML();
        setSourceCode(data);
      }
    }
    setIsSourceMode(!isSourceMode);
    if (isSplitMode) setIsSplitMode(false);
  };

  const handleExportWord = () => {
    if (!editor) return;
    const header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Export HTML to Word</title></head><body>";
    const footer = "</body></html>";
    const html = header + editor.getHTML() + footer;
    const blob = new Blob(['\ufeff', html], {
      type: 'application/msword'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title || 'document'}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportPdf = () => {
    if (!editor) return;
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.write(`
        <html>
          <head>
            <title>${title || 'document'}</title>
            <style>
              body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
                color: #27272a;
                line-height: 1.625;
                padding: 42px;
                max-width: 820px;
                margin: 0 auto;
                background-color: #ffffff;
              }
              h1 {
                font-size: 28px;
                margin-top: 10px;
                margin-bottom: 8px;
                color: #09090b;
                border-bottom: 1.5px solid #e4e4e7;
                padding-bottom: 14px;
                font-weight: 800;
                letter-spacing: -0.025em;
              }
              h2 {
                font-size: 20px;
                margin-top: 28px;
                margin-bottom: 12px;
                color: #18181b;
                font-weight: 700;
                border-bottom: 1px solid #f4f4f5;
                padding-bottom: 4px;
              }
              h3 {
                font-size: 16px;
                margin-top: 22px;
                margin-bottom: 10px;
                color: #27272a;
                font-weight: 600;
              }
              p {
                margin-top: 0;
                margin-bottom: 16px;
                font-size: 14px;
                color: #3f3f46;
              }
              code {
                background-color: #f4f4f5;
                padding: 2.5px 5px;
                border-radius: 4px;
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
                font-size: 0.875em;
                color: #09090b;
              }
              pre {
                background-color: #f8f8f9;
                padding: 16px;
                border-radius: 8px;
                overflow-x: auto;
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
                font-size: 0.875em;
                border: 1px solid #e4e4e7;
                margin-bottom: 16px;
              }
              blockquote {
                border-left: 4.5px solid #4f46e5;
                margin: 0 0 16px 0;
                padding-left: 18px;
                color: #71717a;
                font-style: italic;
              }
              img {
                max-width: 100%;
                height: auto;
                border-radius: 8px;
                margin: 16px 0;
              }
              ul, ol {
                padding-left: 22px;
                margin-bottom: 16px;
                margin-top: 0;
              }
              li {
                margin-bottom: 6px;
                font-size: 14px;
                color: #3f3f46;
              }
            </style>
          </head>
          <body>
            <h1>${title || '无标题'}</h1>
            <div style="margin-top: 20px;">
              ${editor.getHTML()}
            </div>
            <script>
              window.onload = function() {
                window.print();
                setTimeout(() => {
                  window.frameElement.remove();
                }, 100);
              };
            </script>
          </body>
        </html>
      `);
      doc.close();
    }
  };

  const handleExportMarkdown = () => {
    if (!editor) return;
    let markdown = '';
    try {
      if ((editor.storage as any).markdown) {
        markdown = (editor.storage as any).markdown.getMarkdown();
      } else {
        markdown = editor.getText();
      }
    } catch (e) {
      markdown = editor.getText();
    }
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title || 'document'}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportImage = async () => {
    if (!editor) return;
    toast.info('正在渲染高分辨率图片，请稍等...');
    try {
      const html2canvas = (await import('html2canvas')).default;
      
      const container = document.createElement('div');
      container.style.position = 'absolute';
      container.style.top = '-9999px';
      container.style.left = '-9999px';
      container.style.width = '760px';
      container.className = 'bg-white text-zinc-800 p-10 font-sans flex flex-col gap-6 rounded-xl border border-zinc-100 shadow-lg';
      
      const header = document.createElement('div');
      header.className = 'border-b pb-6 flex flex-col gap-2';
      
      const categoryTag = document.createElement('div');
      categoryTag.className = 'text-xs font-bold uppercase tracking-wider text-indigo-600 mb-0.5';
      categoryTag.innerText = '极简知识库 · 精彩笔记分享';
      
      const titleEl = document.createElement('h1');
      titleEl.className = 'text-3xl font-extrabold tracking-tight text-zinc-900 m-0 leading-tight';
      titleEl.innerText = title || '无标题';
      
      const dateEl = document.createElement('div');
      dateEl.className = 'text-xs text-zinc-400 font-medium';
      dateEl.innerText = `生成时间：${new Date().toLocaleString()}`;
      
      header.appendChild(categoryTag);
      header.appendChild(titleEl);
      header.appendChild(dateEl);
      container.appendChild(header);
      
      const content = document.createElement('div');
      content.className = 'prose max-w-none text-[14.5px] leading-relaxed text-zinc-700 space-y-4';
      content.innerHTML = editor.getHTML();
      
      const style = document.createElement('style');
      style.innerHTML = `
        .prose h1, .prose h2, .prose h3 { color: #09090b; font-weight: 700; margin-top: 1.6em; margin-bottom: 0.6em; }
        .prose h1 { font-size: 1.5em; letter-spacing: -0.025em; }
        .prose h2 { font-size: 1.25em; border-bottom: 1px solid #f4f4f5; padding-bottom: 0.3em; letter-spacing: -0.015em; }
        .prose h3 { font-size: 1.1em; }
        .prose p { margin-bottom: 1.1em; margin-top: 0; color: #27272a; line-height: 1.65; }
        .prose blockquote { border-left: 4.5px solid #4f46e5; padding-left: 1.1rem; color: #71717a; font-style: italic; margin-left: 0; margin-bottom: 1.1em; }
        .prose pre { background: #f8f8f9; padding: 1rem; border-radius: 8px; overflow-x: auto; font-family: monospace; font-size: 0.85em; border: 1px solid #e4e4e7; margin-bottom: 1.1em; }
        .prose code { background: #f4f4f5; padding: 0.15rem 0.3rem; border-radius: 4px; font-family: monospace; font-size: 0.9em; color: #09090b; }
        .prose ul { list-style-type: disc; padding-left: 1.5rem; margin-bottom: 1.1em; }
        .prose ol { list-style-type: decimal; padding-left: 1.5rem; margin-bottom: 1.1em; }
        .prose li { margin-bottom: 0.5em; color: #27272a; }
        .prose img { max-width: 100%; border-radius: 8px; margin: 1em 0; border: 1px solid #f4f4f5; }
      `;
      container.appendChild(style);
      container.appendChild(content);
      
      const footer = document.createElement('div');
      footer.className = 'border-t pt-5 mt-4 flex justify-between items-center text-[11px] text-zinc-400 font-medium';
      
      const leftFoot = document.createElement('div');
      leftFoot.innerText = 'Power by 极简知识库 AI Writing';
      
      const rightFoot = document.createElement('div');
      rightFoot.className = 'italic text-indigo-500 font-semibold';
      rightFoot.innerText = 'Minimalist Knowledge Base';
      
      footer.appendChild(leftFoot);
      footer.appendChild(rightFoot);
      container.appendChild(footer);
      
      document.body.appendChild(container);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const canvas = await html2canvas(container, {
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        scale: 2
      });
      
      const imgData = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = imgData;
      link.download = `${title || 'document'}.png`;
      document.body.appendChild(link);
      link.click();
      
      document.body.removeChild(link);
      document.body.removeChild(container);
      toast.success('图片生成成功，已开始下载！');
    } catch (e: any) {
      console.error(e);
      toast.error('图片生成失败: ' + (e.message || e));
    }
  };

  const handleAiAction = async (action: string, customPrompt?: string) => {
    if (!editor) return;
    
    setAiLoading(true);
    const selection = editor.state.selection;
    const text = editor.state.doc.textBetween(selection.from, selection.to) || editor.getText();
    const context = editor.getText();
    
    try {
      const result = await AIService.handleAIAction(action, text, context, customPrompt);
      editor.commands.insertContent(result);
    } catch (e: any) {
      toast.error(e.message || 'AI generation failed');
    } finally {
      setAiLoading(false);
    }
  };

  const [portalNode, setPortalNode] = useState<Element | null>(null);

  useLayoutEffect(() => {
    setPortalNode(document.getElementById('editor-toolbar-portal'));
  }, []);

  if (!editor) {
    return null;
  }

  const defaultInsertTools = [
    {
      name: '图片',
      hasDropdown: true,
      onClick: () => {},
      dropdownContent: (
        <>
          <DropdownItem onClick={() => fileInputRef.current?.click()} text="本地上传" />
          <DropdownItem onClick={() => onOpenImageGallery?.()} text="从图片库选择" />
          <DropdownItem onClick={() => onWechatScan?.()} text="微信扫码上传" />
          <DropdownDivider />
          <DropdownItem 
             onClick={() => onOpenAiImage?.()} 
             icon={<Sparkles size={11} className="text-amber-500 animate-pulse" />} 
             text="AI 配图" 
             highlighted 
          />
        </>
      )
    },
    {
      name: t('audio', { defaultValue: '音频' }),
      hasDropdown: true,
      onClick: () => {},
      dropdownContent: (
        <>
          <DropdownItem onClick={() => audioInputRef.current?.click()} text={t('uploadLocalAudio', { defaultValue: '上传本地音频' })} />
          <DropdownItem onClick={() => audioInputRef.current?.click()} text={t('uploadLocalMusic', { defaultValue: '上传本地音乐' })} />
          <DropdownItem onClick={() => onAudioGallery?.()} text={t('selectFromAssets', { defaultValue: '从素材库中选择' })} />
          <DropdownItem onClick={() => onAudioGallery?.()} text={t('aiAudioGen', { defaultValue: 'AI生成音频' })} />
          <DropdownItem onClick={() => onAudioGallery?.()} text={t('aiMusicGen', { defaultValue: 'AI生成音乐' })} />
        </>
      )
    },
    {
      name: t('video', { defaultValue: '视频' }),
      hasDropdown: true,
      onClick: () => {},
      dropdownContent: (
        <>
          <DropdownItem onClick={() => videoInputRef.current?.click()} text={t('uploadLocalVideo', { defaultValue: '本地上传' })} />
          <DropdownItem onClick={() => onVideoGallery?.()} text={t('selectFromVideos', { defaultValue: '从视频库选择' })} />
        </>
      )
    }
  ];

  const defaultConfig: UniversalToolbarGroup[] = [
    { type: 'typography' },
    { type: 'format' },
    { type: 'list' },
    { type: 'insert', tools: defaultInsertTools },
    { type: 'history' },
    { type: 'view' },
    { type: 'export' }
  ];

  const toolbarContent = (
    <>
      <input 
         type="file" 
         ref={fileInputRef} 
         className="hidden" 
         accept="image/*"
         multiple
         onChange={(e) => {
           handleImageFiles(e.target.files, editor);
           if (e.target) e.target.value = '';
         }}
      />
      <input 
         type="file" 
         ref={videoInputRef} 
         className="hidden" 
         accept="video/*"
         multiple
         onChange={(e) => {
           if (e.target.files && e.target.files.length > 0) {
             const file = e.target.files[0];
             const url = URL.createObjectURL(file);
             editor?.commands.insertContent({
               type: 'video',
               attrs: { src: url, controls: true }
             });
           }
           if (e.target) e.target.value = '';
         }}
      />
      <input 
         type="file" 
         ref={audioInputRef} 
         className="hidden" 
         accept="audio/*"
         multiple
         onChange={(e) => {
           if (e.target.files && e.target.files.length > 0) {
             const file = e.target.files[0];
             const url = URL.createObjectURL(file);
             editor?.commands.insertContent({
               type: 'audio',
               attrs: { src: url, controls: true }
             });
           }
           if (e.target) e.target.value = '';
         }}
      />
      <UniversalToolbar
        editor={editor}
        t={t}
        config={toolbarConfig || defaultConfig}
        handleToggleSourceMode={handleToggleSourceMode}
        isSourceMode={isSourceMode}
        isSplitMode={isSplitMode}
        setIsSplitMode={(val) => {
           setIsSplitMode(val);
           if (val) {
              setIsSourceMode(false);
              const data = mode === 'markdown' ? (editor.storage as any).markdown.getMarkdown() : editor.getHTML();
              setSourceCode(data);
           }
        }}
        handleExportWord={handleExportWord}
        handleExportPdf={handleExportPdf}
        handleExportMarkdown={handleExportMarkdown}
        handleExportImage={handleExportImage}
      />
    </>
  );

  return (
    <div className="w-full flex-1 flex flex-col h-full min-h-0 relative">
      {portalNode ? (
        createPortal(toolbarContent, portalNode)
      ) : (
        <div className="w-full border-b border-zinc-200/80 dark:border-[var(--color-kb-panel-border)]/80 bg-white dark:bg-[var(--color-kb-panel)] select-none h-[40px] flex items-center px-4 shrink-0 overflow-visible shadow-sm z-30">
          {toolbarContent}
        </div>
      )}
      {isWechatAppletModalOpen && (
        <WechatAppletModal 
          onClose={() => setIsWechatAppletModalOpen(false)}
          onConfirm={(data) => {
            editor.commands.insertContent({
              type: 'wechatMiniprogram',
              attrs: {
                'data-miniprogram-type': data.displayType,
                'data-miniprogram-title': data.displayType === 'card' ? data.cardTitle : data.textContent,
                'data-miniprogram-imageurl': data.imageUrl,
                'data-miniprogram-path': data.link,
                'data-miniprogram-nickname': '小程序'
              }
            });
            if (data.displayType === 'card' || data.displayType === 'image') {
              editor.commands.insertContent('<p></p>');
            }
          }}
        />
      )}
      {editor && (
        <EditorBubbleMenu 
          editor={editor}
          t={t}
          aiLoading={aiLoading}
          handleAiAction={handleAiAction}
        />
      )}
      <div className="relative flex-1 flex flex-col min-h-0 overflow-y-auto w-full h-full p-0 m-0 no-scrollbar">
        {!hideTitle && (
          <div className="w-full flex flex-col select-text shrink-0 px-6 pt-6 pb-2 max-w-4xl mx-auto">
            <input
              type="text"
              placeholder={t('untitledNote', { defaultValue: '无标题' })}
              value={title}
              onChange={(e) => handleTitleChangeLocal(e.target.value)}
              className="w-full bg-transparent border-none text-3xl font-extrabold tracking-tight text-[var(--color-kb-text-heading)] outline-none focus:outline-none focus:ring-0 p-0 placeholder-zinc-300 dark:placeholder-zinc-700"
            />
            <div className="h-px bg-[var(--color-kb-panel-border)]/55 mt-4"></div>
          </div>
        )}

        {aiLoading && (
          <div className="absolute top-4 right-4 flex items-center bg-[var(--color-kb-panel)] text-[var(--color-kb-accent)] text-xs font-medium px-3 py-1.5 rounded-full shadow-sm animate-pulse z-10 border border-[var(--color-kb-panel-border)]">
            <Sparkles size={12} className="mr-1.5" /> {t('aiProcessing')}
          </div>
        )}
        {isSourceMode && !isSplitMode && (
          <textarea
            value={sourceCode}
            onChange={(e) => setSourceCode(e.target.value)}
            className="w-full max-w-4xl mx-auto px-6 py-6 flex-1 bg-transparent text-[var(--color-kb-text)] font-mono text-sm border-none focus:outline-none resize-none"
            spellCheck={false}
          />
        )}
        {isSplitMode && (
          <div className="flex w-full gap-0 border-t border-[var(--color-kb-panel-border)] flex-1 h-full min-h-0">
            <div className="w-1/2 h-full flex flex-col border-r border-[var(--color-kb-panel-border)] overflow-hidden bg-[var(--color-kb-panel-hover)]">
               <textarea
                 value={sourceCode}
                 onChange={(e) => {
                   setSourceCode(e.target.value);
                   editor.commands.setContent(e.target.value);
                   onChange?.(e.target.value);
                 }}
                 className="w-full h-full p-6 bg-transparent text-[var(--color-kb-text)] font-mono text-sm border-none focus:outline-none resize-none"
                 spellCheck={false}
               />
            </div>
            <div className="w-1/2 h-full overflow-y-auto bg-[var(--color-kb-editor)] p-6">
               <EditorContent editor={editor} className="h-full flex flex-col flex-1 min-h-0 w-full" />
            </div>
          </div>
        )}
        {!isSourceMode && !isSplitMode && (
          <EditorContent editor={editor} className="w-full max-w-4xl mx-auto px-6 pb-24" />
        )}
      </div>
    </div>
  );
}
