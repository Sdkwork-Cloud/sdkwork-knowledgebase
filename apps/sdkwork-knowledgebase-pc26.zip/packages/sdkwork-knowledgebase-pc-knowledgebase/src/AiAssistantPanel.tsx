import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, X, ChevronDown, User, Bot, Loader2, Paperclip, File, Check, Terminal, Activity, Code, Cpu, Play, CheckCircle2, Wand2, Mic, Plus } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useLocalStorage } from '@packages/sdkwork-knowledgebase-pc-commons/src';
import { DocumentMeta, FolderNode } from './services/document';
import { AIService } from './services/ai';
import { McpAgentService, McpToolCall } from './services/mcpAgent';
import DOMPurify from 'dompurify';
import { marked } from 'marked';
import { AiAssistantInput } from './AiAssistantInput';

const VENDORS = [
  { id: 'google', name: 'Google' },
  { id: 'openai', name: 'OpenAI' },
  { id: 'anthropic', name: 'Anthropic' },
  { id: 'deepseek', name: 'DeepSeek' },
];

const MODELS: Record<string, {id: string, name: string}[]> = {
  google: [
    { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro' },
    { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash' },
  ],
  openai: [
    { id: 'gpt-4o', name: 'GPT-4o' },
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini' },
    { id: 'o1-mini', name: 'o1 Mini' },
    { id: 'o3-mini', name: 'o3 Mini' }
  ],
  anthropic: [
    { id: 'claude-3-5-sonnet', name: 'Claude 3.5 Sonnet' },
    { id: 'claude-3-opus', name: 'Claude 3 Opus' },
  ],
  deepseek: [
    { id: 'deepseek-chat', name: 'DeepSeek V3' },
    { id: 'deepseek-reasoner', name: 'DeepSeek R1' },
  ]
};

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  references?: DocumentMeta[];
  toolCalls?: McpToolCall[];
}

export interface AiAssistantPanelProps {
  aiWidth: number;
  isDraggingAi: boolean;
  onMouseDownDrag: () => void;
  onClose: () => void;
  docContent?: string;
  docs?: (FolderNode | DocumentMeta)[];
  activeDoc?: DocumentMeta | null;
  activeKbId?: string;
  headerHeightClass?: string;
  onSendMessage?: (msg: string, refs: DocumentMeta[], setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>, setIsTyping: React.Dispatch<React.SetStateAction<boolean>>) => void;
  selectedArticle?: any;
  onUpdateArticle?: (updates: any) => void;
  onTriggerStreamRewrite?: () => void;
  onTriggerStreamContinue?: () => void;
  onTriggerCreateNewArticle?: (title: string, promptTopic?: string) => void;
  onInsertHtml?: (html: string) => void;
}

export function AiAssistantPanel({
  aiWidth, isDraggingAi, onMouseDownDrag, onClose, docContent, docs = [], activeDoc, activeKbId,
  headerHeightClass = 'h-[40px]', onSendMessage, selectedArticle, onUpdateArticle, onTriggerStreamRewrite,
  onTriggerStreamContinue, onTriggerCreateNewArticle, onInsertHtml
}: AiAssistantPanelProps) {
  const { t } = useTranslation(['editor', 'mcp']);
  const [isModelSelectorOpen, setIsModelSelectorOpen] = useState(false);
  const [activeVendor, setActiveVendor] = useLocalStorage('ai-active-vendor', 'google');
  const [activeModel, setActiveModel] = useLocalStorage('ai-active-model', MODELS.google[0]);
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isDocSelectorOpen, setIsDocSelectorOpen] = useState(false);
  const [selectedReferences, setSelectedReferences] = useState<DocumentMeta[]>([]);

  const typeInEditorIntervalRef = useRef<any>(null);
  const typewriterIntervalRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (typeInEditorIntervalRef.current) clearInterval(typeInEditorIntervalRef.current);
      if (typewriterIntervalRef.current) clearInterval(typewriterIntervalRef.current);
    };
  }, []);

  useEffect(() => {
    // Clear references when switching knowledge base
    setSelectedReferences([]);
  }, [activeKbId]);

  useEffect(() => {
    // If there's an active doc, we could automatically suggest referencing it, 
    // or we can allow manual referencing. Let's just update references when user explicitly chooses.
  }, [activeDoc]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleDefaultSend = async (userMessage: string, currentRefs: DocumentMeta[]) => {
    if (onSendMessage) {
       onSendMessage(userMessage, currentRefs, setMessages, setIsTyping);
       return;
    }

    try {
      // Run local Client-Side MCP Agent query to match user intent directly
      await new Promise(r => setTimeout(r, 650));
      const result = McpAgentService.processUserQuery(userMessage, selectedArticle);
      
      const isCreateNew = userMessage.includes('新建') || userMessage.includes('新写') || userMessage.includes('写篇') || userMessage.includes('写一篇');
      const isToolTriggered = (result.toolCalls && result.toolCalls.length > 0) || isCreateNew;

      if (isToolTriggered) {
        if (result.updatedArticleFields && Object.keys(result.updatedArticleFields).length > 0) {
          onUpdateArticle?.(result.updatedArticleFields);
        }

        if (result.insertHtml && onInsertHtml) {
          onInsertHtml(result.insertHtml);
        }

        setMessages(prev => [...prev, { 
          role: 'assistant', 
          content: result.responseText,
          toolCalls: result.toolCalls
        }]);

        if (result.triggerStreamRewrite) {
          onTriggerStreamRewrite?.();
        }

        if (result.triggerStreamContinue) {
          onTriggerStreamContinue?.();
        }

        if (result.triggerCreateNewArticle) {
          onTriggerCreateNewArticle?.(result.triggerCreateNewArticle.title, result.triggerCreateNewArticle.topic);
        }

        setIsTyping(false);
      } else if (selectedArticle) {
        let { result: responseText, toolCalls } = await AIService.generateChatResponse(
           userMessage,
           docContent,
           currentRefs.map(r => r.title).join(',')
        );

        if (toolCalls && toolCalls.length > 0) {
          // Simulate tool execution
          setMessages(prev => [...prev, { role: 'assistant', content: '', toolCalls: toolCalls.map(tc => ({...tc, status: 'running'})) }]);
          
          for (let i = 0; i < toolCalls.length; i++) {
             await new Promise(r => setTimeout(r, 800)); // Delay per tool
             setMessages(prev => {
                const newMsgs = [...prev];
                const lastMsg = newMsgs[newMsgs.length - 1];
                if (lastMsg && lastMsg.role === 'assistant' && lastMsg.toolCalls) {
                   lastMsg.toolCalls[i] = { ...toolCalls[i], status: 'success' };
                }
                return newMsgs;
             });
          }
        } else {
             setMessages(prev => [...prev, { role: 'assistant', content: '', toolCalls: [] }]);
        }

        const insertMatch = responseText.match(/<insert_to_note>([\s\S]*?)<\/insert_to_note>/i);
        if (insertMatch && onInsertHtml) {
          const insertContent = insertMatch[1].trim();
          
          // Simulate typing effect in editor
          let editorIndex = 0;
          const editorChars = Array.from(insertContent);
          
          if (typeInEditorIntervalRef.current) clearInterval(typeInEditorIntervalRef.current);
          const typeInEditorInterval = setInterval(() => {
             onInsertHtml(editorChars[editorIndex]);
             editorIndex++;
             if (editorIndex >= editorChars.length) {
               clearInterval(typeInEditorInterval);
               typeInEditorIntervalRef.current = null;
             }
          }, 15);
          typeInEditorIntervalRef.current = typeInEditorInterval;

          responseText = responseText.replace(/<insert_to_note>[\s\S]*?<\/insert_to_note>/i, '').trim();
          if (!responseText) {
            responseText = '*(已自动执行插入文档操作)*';
          }
        }

        // Typewriter effect
        const chars = Array.from(responseText);
        let index = 0;
        
        if (typewriterIntervalRef.current) clearInterval(typewriterIntervalRef.current);
        const intervalId = setInterval(() => {
          setMessages(prev => {
            const newMessages = [...prev];
            const lastMsgIndex = newMessages.length - 1;
            if (lastMsgIndex >= 0 && newMessages[lastMsgIndex].role === 'assistant') {
               newMessages[lastMsgIndex].content = chars.slice(0, index + 1).join('');
            }
            return newMessages;
          });
          index++;
          if (index >= chars.length) {
            clearInterval(intervalId);
            typewriterIntervalRef.current = null;
            setIsTyping(false);
          }
        }, 20);
        typewriterIntervalRef.current = intervalId;
      }
    } catch (e: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: (t('processError', { ns: 'mcp' }) || '处理请求时发生错误: ') + (e.message || '') }]);
      setIsTyping(false);
    }
  };

  const handleAbort = () => {
    if (typeInEditorIntervalRef.current) {
      clearInterval(typeInEditorIntervalRef.current);
      typeInEditorIntervalRef.current = null;
    }
    if (typewriterIntervalRef.current) {
      clearInterval(typewriterIntervalRef.current);
      typewriterIntervalRef.current = null;
    }
    setIsTyping(false);
  };

  const handleSend = async () => {
    if (!inputValue.trim() || isTyping) return;

    const userMessage = inputValue.trim();
    const currentRefs = [...selectedReferences];
    setInputValue('');
    setSelectedReferences([]);
    setMessages(prev => [...prev, { role: 'user', content: userMessage, references: currentRefs }]);
    setIsTyping(true);

    handleDefaultSend(userMessage, currentRefs);
  };

  const triggerQuickTool = async (commandText: string) => {
    if (isTyping) return;
    setInputValue('');
    setIsDocSelectorOpen(false);
    setMessages(prev => [...prev, { role: 'user', content: commandText, references: [] }]);
    setIsTyping(true);
    await handleDefaultSend(commandText, []);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Helper to extract flat list of non-folder docs
  const extractFlatDocs = (items: (FolderNode | DocumentMeta)[]): DocumentMeta[] => {
    let result: DocumentMeta[] = [];
    for (const item of items) {
      if (item.type === 'folder') {
        if ((item as FolderNode).children) {
           result = [...result, ...extractFlatDocs((item as FolderNode).children)];
        }
      } else {
        result.push(item as DocumentMeta);
      }
    }
    return result;
  };

  const flatDocs = extractFlatDocs(docs);

  const toggleReference = (doc: DocumentMeta) => {
    setSelectedReferences(prev => {
      if (prev.find(d => d.id === doc.id)) {
        return prev.filter(d => d.id !== doc.id);
      }
      return [...prev, doc];
    });
  };

  const formatMessageContent = (content: string) => {
    try {
      const rawHtml = marked.parse(content, { async: false }) as string;
      return { __html: DOMPurify.sanitize(rawHtml) };
    } catch {
      return { __html: DOMPurify.sanitize(content) };
    }
  };

  return (
    <div 
      className="flex flex-col bg-[#fafafa] dark:bg-[var(--color-kb-editor)] border-l border-zinc-200/80 dark:border-[var(--color-kb-panel-border)] relative flex-shrink-0 shadow-[-8px_0_24px_-12px_rgba(0,0,0,0.08)] z-30"
      style={{ width: `${aiWidth}px` }}
    >
      {/* Resize Handle */}
      <div 
        className="absolute left-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-[var(--color-kb-accent)]/50 transition-colors z-20 group -ml-[2px]"
        onMouseDown={onMouseDownDrag}
      >
        <div className={`absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-[3px] h-12 rounded-full transition-colors opacity-0 group-hover:opacity-100 ${isDraggingAi ? 'bg-[var(--color-kb-accent)] opacity-100' : 'bg-[var(--color-kb-accent)]/80'}`}></div>
      </div>
      
      <div className={`${headerHeightClass} border-b border-zinc-200/80 dark:border-[var(--color-kb-panel-border)]/80 bg-white dark:bg-[var(--color-kb-panel)] flex items-center justify-between px-4 shrink-0 select-none backdrop-blur-md z-30 shadow-sm relative`}>
        <button 
          type="button"
          onClick={() => setIsModelSelectorOpen(!isModelSelectorOpen)}
          className="flex items-center text-zinc-900 dark:text-[var(--color-kb-text-heading)] font-bold text-[12.5px] hover:bg-zinc-100 dark:hover:bg-[var(--color-kb-panel-hover)] px-2.5 py-1 -ml-1 rounded-lg transition-all group border border-transparent hover:border-zinc-200/80 dark:hover:border-transparent cursor-pointer active:scale-95"
        >
          <div className="w-4.5 h-4.5 rounded flex items-center justify-center bg-indigo-50 dark:bg-indigo-500/10 mr-1.5 border border-indigo-100 dark:border-indigo-500/20 shadow-[inset_0_1px_rgba(255,255,255,0.8)]">
            <Sparkles size={11} className="text-indigo-600 dark:text-indigo-400" strokeWidth={2.5} />
          </div>
          {activeModel ? activeModel.name : t('aiAssistant')}
          <ChevronDown size={11} className="ml-1 text-zinc-400 dark:text-[var(--color-kb-text-muted)] group-hover:text-zinc-600 dark:group-hover:text-[var(--color-kb-text)] transition-colors" strokeWidth={2.5} />
        </button>

        {isModelSelectorOpen && (
          <>
            <div className="fixed inset-0 z-[9998]" onClick={() => setIsModelSelectorOpen(false)} />
            <div className="absolute top-full left-4 mt-1 bg-white dark:bg-[var(--color-kb-editor)] border border-zinc-200/80 dark:border-[var(--color-kb-panel-border)] shadow-xl rounded-xl z-[9999] flex w-[320px] max-h-[300px] overflow-hidden animate-in fade-in slide-in-from-top-2">
              <div className="w-[110px] border-r border-zinc-100 dark:border-[var(--color-kb-panel-border)] bg-zinc-50/50 dark:bg-[var(--color-kb-panel)]/50 p-1.5 shrink-0 overflow-y-auto hover-scrollbar text-left flex flex-col gap-0.5">
                {VENDORS.map(v => (
                   <button 
                    key={v.id}
                    onClick={() => setActiveVendor(v.id)}
                    className={`w-full text-left px-2.5 py-1.5 text-[12.5px] rounded-lg transition-colors font-medium ${activeVendor === v.id ? 'bg-white dark:bg-[var(--color-kb-editor)] shadow-[0_1px_2px_rgba(0,0,0,0.05)] text-indigo-600 dark:text-[var(--color-kb-accent)]' : 'text-zinc-500 hover:bg-black/5 dark:hover:bg-[var(--color-kb-panel-hover)]'}`}
                   >
                      {v.name}
                   </button>
                ))}
              </div>
              <div className="flex-1 p-1.5 overflow-y-auto hover-scrollbar flex flex-col gap-0.5">
                {(MODELS[activeVendor] || []).map(m => (
                   <button 
                    key={m.id}
                    onClick={() => { setActiveModel(m); setIsModelSelectorOpen(false); }}
                    className={`w-full text-left px-2.5 py-1.5 text-[12.5px] rounded-lg transition-colors flex items-center justify-between group ${activeModel?.id === m.id ? 'bg-indigo-50/80 dark:bg-[var(--color-kb-accent)]/10 text-indigo-700 dark:text-indigo-300' : 'text-zinc-700 dark:text-[var(--color-kb-text)] hover:bg-black/5 dark:hover:bg-[var(--color-kb-panel-hover)]'}`}
                   >
                      <span className="font-medium truncate mr-2">{m.name}</span>
                      {activeModel?.id === m.id && <Check size={14} className="text-indigo-500 shrink-0" />}
                   </button>
                ))}
              </div>
            </div>
          </>
        )}

        <button 
          type="button"
          onClick={onClose} 
          className="text-zinc-400 dark:text-[var(--color-kb-text-muted)] hover:text-red-500 hover:bg-red-50 dark:hover:text-red-500 dark:hover:bg-red-500/10 p-1 rounded-md transition-all active:scale-95 border border-transparent"
          title={t('closeAiAssistant', { ns: 'mcp' }) || '关闭AI助手'}
        >
          <X size={14} strokeWidth={2.5} />
        </button>
      </div>
      
      <div className="flex-1 overflow-hidden hover:overflow-y-auto hover-scrollbar p-4 space-y-4" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="flex flex-col space-y-1.5">
            <div className="text-xs text-zinc-400 dark:text-[var(--color-kb-text-muted)] text-center mb-2 font-medium">{t('aiGreetingTime')}</div>
            <div className="flex justify-start mb-2">
               <div className="bg-white dark:bg-[var(--color-kb-panel-hover)] border-2 border-zinc-200/80 dark:border-[var(--color-kb-panel-border)]/50 rounded-3xl p-5 text-sm text-zinc-800 dark:text-[var(--color-kb-text)] w-full break-words shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 -mr-6 -mt-6 w-24 h-24 bg-indigo-50 dark:bg-indigo-500/5 rounded-full blur-[20px] transition-all group-hover:bg-indigo-100/80 dark:group-hover:bg-indigo-500/10"></div>
                
                <div className="relative z-10">
                  <div className="markdown-body font-medium leading-relaxed" dangerouslySetInnerHTML={formatMessageContent(t('aiGreetingText'))} />
                  <ul className="list-disc pl-5 mt-3 space-y-2 text-[13px] font-medium text-zinc-500 dark:text-[var(--color-kb-text-muted)] mb-4 marker:text-indigo-300 dark:marker:text-indigo-600">
                    <li>{t('aiHelpSummarize')}</li>
                    <li>{t('aiHelpWrite')}</li>
                    <li>{t('aiHelpAsk')}</li>
                    <li>{t('aiHelpGenerate')}</li>
                  </ul>
                </div>

                <div className="h-px bg-zinc-100 dark:bg-[var(--color-kb-panel-border)]/50 my-4 relative z-10"></div>
                <div className="space-y-3 relative z-10">
                  <span className="text-[11px] font-extrabold text-indigo-500 dark:text-[var(--color-kb-text-muted)] tracking-wider flex items-center gap-1">
                    <Sparkles size={12} strokeWidth={2.5} /> {t('coreSkills', { ns: 'mcp' })}
                  </span>
                  <div className="flex flex-wrap gap-2.5">
                    {[
                      { label: t('chipStyles', { ns: 'mcp' }), cmd: t('quickStyles', { ns: 'mcp' }) },
                      { label: t('chipHeadlines', { ns: 'mcp' }), cmd: t('quickHeadlines', { ns: 'mcp' }) },
                      { label: t('chipInsert', { ns: 'mcp' }), cmd: t('quickInsert', { ns: 'mcp' }) },
                      { label: t('chipDiagnose', { ns: 'mcp' }), cmd: t('quickDiagnose', { ns: 'mcp' }) },
                      { label: t('chipRewrite', { ns: 'mcp' }), cmd: t('quickRewrite', { ns: 'mcp' }) }
                    ].map((chip, i) => (
                      <button 
                        key={i}
                        type="button"
                        onClick={() => triggerQuickTool(chip.cmd)}
                        disabled={isTyping}
                        className="px-3.5 py-1.5 text-[12px] font-bold bg-[#fafafa] dark:bg-[var(--color-kb-editor)] border border-zinc-200/80 dark:border-[var(--color-kb-panel-border)] hover:border-indigo-300 dark:hover:border-[var(--color-kb-accent)]/40 hover:bg-indigo-50 dark:hover:bg-[var(--color-kb-accent)]/5 text-zinc-700 dark:text-[var(--color-kb-text)] rounded-full transition-all cursor-pointer shadow-sm hover:shadow active:scale-95 disabled:opacity-50 hover:text-indigo-700 dark:hover:text-indigo-300"
                      >
                        {chip.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={idx} className={`flex mb-4 animate-in slide-in-from-bottom-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
             <div className={`flex flex-col ${msg.role === 'user' ? 'items-end max-w-[92%]' : 'items-start w-full'}`}>
                {msg.references && msg.references.length > 0 && (
                   <div className="flex flex-wrap gap-1 mb-1 justify-end">
                      {msg.references.map(ref => (
                         <div key={ref.id} className="flex items-center text-[10px] uppercase font-bold bg-indigo-50/50 dark:bg-[var(--color-kb-panel-hover)] border border-indigo-100 dark:border-[var(--color-kb-panel-border)] text-indigo-500 dark:text-[var(--color-kb-text-muted)] px-1.5 py-0.5 rounded shadow-sm">
                            <File size={10} className="mr-1 opacity-70" />
                            <span className="truncate max-w-[120px]">{ref.title}</span>
                         </div>
                      ))}
                   </div>
                )}
                <div 
                  className={`rounded-2xl p-3.5 text-sm break-words flex flex-col shadow-sm ${msg.role === 'user' ? 'bg-[var(--color-kb-accent)] text-white font-medium shadow-indigo-500/20' : 'w-full bg-white dark:bg-[var(--color-kb-panel-hover)] border border-zinc-200/80 dark:border-[var(--color-kb-panel-border)]/55 text-zinc-800 dark:text-[var(--color-kb-text)] rounded-tl-sm markdown-body'} ${msg.role === 'assistant' ? 'whitespace-normal' : 'whitespace-pre-wrap'}`}
                  dangerouslySetInnerHTML={msg.role === 'assistant' ? formatMessageContent(msg.content) : undefined}
                >
                   {msg.role === 'user' ? msg.content : undefined}
                </div>

                {/* MCP Tool Calls Terminal display */}
                {msg.role === 'assistant' && msg.toolCalls && msg.toolCalls.length > 0 && (
                  <div className="w-full mt-2 space-y-1.5">
                    {msg.toolCalls.map((tc, tcIdx) => {
                      const toolNameMap: Record<string, string> = {
                        search_knowledge_base: t('tool_search_kb', { defaultValue: '检索相关文档与知识' }),
                        write_to_note: t('tool_write_note', { defaultValue: '提炼结构化信息并写入文档' }),
                        analyze_intent: t('tool_analyze_intent', { defaultValue: '分析上下文与意图' }),
                        insert_content: t('tool_insert_content', { defaultValue: '执行正文内容的追加与修改' }),
                      };
                      return (
                        <div key={tcIdx} className="overflow-hidden rounded-xl border border-indigo-100 dark:border-indigo-900/30 bg-gradient-to-r from-indigo-50/50 to-white dark:from-indigo-950/20 dark:to-transparent shadow-sm">
                          <div className="flex items-center px-3 py-2 text-[12px] text-slate-700 dark:text-indigo-200 font-medium">
                            {tc.status === 'running' ? (
                                <Loader2 size={13} className="text-indigo-500 dark:text-indigo-400 animate-spin mr-2 shrink-0" />
                            ) : (
                                <CheckCircle2 size={13} className="text-emerald-500 dark:text-emerald-400 mr-2 shrink-0" />
                            )}
                            <span className="truncate">{toolNameMap[tc.name] || tc.name}</span>
                          </div>
                          {tc.status !== 'running' && tc.result && (
                            <div className="px-3 pb-2 pt-0.5">
                              <div className="text-[11px] text-slate-500 dark:text-indigo-300/70 border-l-[1.5px] border-indigo-200 dark:border-indigo-800 pl-2 py-0.5 whitespace-pre-wrap font-sans">
                                  {tc.result}
                              </div>
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
             </div>
          </div>
        ))}

        {isTyping && (
           <div className="flex items-center space-x-2 text-zinc-400 dark:text-[var(--color-kb-text-muted)] mt-2 font-medium">
              <Loader2 size={14} className="animate-spin text-indigo-500" />
              <span className="text-xs">{t('aiProcessing')}</span>
           </div>
        )}
      </div>
      
      {/* Selected References Display */}
      {selectedReferences.length > 0 && (
        <div className="px-4 py-2.5 border-t border-zinc-200 dark:border-[var(--color-kb-editor-border)] bg-[#fafafa] dark:bg-[var(--color-kb-panel)] flex flex-wrap gap-2 overflow-x-auto no-scrollbar shrink-0 shadow-[0_-4px_10px_-4px_rgba(0,0,0,0.02)] z-10">
          {selectedReferences.map(ref => (
            <div key={ref.id} className="flex items-center text-xs bg-indigo-50 dark:bg-[var(--color-kb-editor)] border border-indigo-200/50 dark:border-[var(--color-kb-accent)]/30 text-indigo-600 dark:text-[var(--color-kb-accent)] px-2 py-1 rounded-md shadow-sm">
              <File size={12} className="mr-1.5 opacity-80" />
              <span className="truncate max-w-[100px] font-bold">{ref.title}</span>
              <button 
                onClick={() => toggleReference(ref)} 
                className="ml-1.5 p-0.5 hover:bg-indigo-200/50 dark:hover:bg-[var(--color-kb-accent)]/10 rounded-full transition-colors opacity-70 hover:opacity-100"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Document Selector Popover */}
      {isDocSelectorOpen && (
        <div className="absolute bottom-[75px] left-4 right-4 bg-white dark:bg-[var(--color-kb-editor)] border border-zinc-200/80 dark:border-[var(--color-kb-panel-border)] shadow-2xl rounded-xl z-50 flex flex-col max-h-[240px] animate-in fade-in slide-in-from-bottom-2 overflow-hidden backdrop-blur-md">
          <div className="px-3.5 py-2.5 border-b border-zinc-100 dark:border-[var(--color-kb-panel-border)] text-xs font-bold text-zinc-500 dark:text-[var(--color-kb-text-muted)] flex justify-between items-center bg-[#fafafa]/50 dark:bg-transparent">
            <span>{t('referToFiles', { ns: 'mcp' }) || '引入文档上下文'}</span>
            <button onClick={() => setIsDocSelectorOpen(false)} className="hover:bg-black/5 dark:hover:bg-[var(--color-kb-panel-hover)] rounded p-1 transition-colors">
              <X size={14} />
            </button>
          </div>
          <div className="overflow-y-auto p-1.5 py-1.5 user-select-none">
            {flatDocs.length === 0 ? (
              <div className="text-center text-xs text-zinc-400 dark:text-[var(--color-kb-text-muted)] py-6">{t('noDocAvailable', { ns: 'mcp' }) || '无可用文档'}</div>
            ) : (
              flatDocs.map(doc => {
                const isSelected = !!selectedReferences.find(d => d.id === doc.id);
                return (
                  <button
                    key={doc.id}
                    onClick={() => toggleReference(doc)}
                    className="w-full flex items-center px-2.5 py-2 hover:bg-black/5 dark:hover:bg-[var(--color-kb-panel-hover)] rounded-lg text-sm text-zinc-700 dark:text-[var(--color-kb-text)] transition-colors text-left"
                  >
                    <div className={`mr-2.5 flex items-center justify-center w-4 h-4 rounded border transition-colors ${isSelected ? 'border-indigo-500 bg-indigo-500 dark:border-[var(--color-kb-accent)] dark:bg-[var(--color-kb-accent)] text-white shadow-sm' : 'border-zinc-300 dark:border-[var(--color-kb-text-muted)]'}`}>
                      {isSelected && <Check size={10} strokeWidth={3} />}
                    </div>
                    <File size={14} className="mr-2 text-zinc-400 dark:text-[var(--color-kb-text-muted)]" />
                    <span className="truncate flex-1 font-medium">{doc.title}</span>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}

      <AiAssistantInput
        inputValue={inputValue}
        setInputValue={setInputValue}
        isTyping={isTyping}
        selectedReferences={selectedReferences}
        isDocSelectorOpen={isDocSelectorOpen}
        setIsDocSelectorOpen={setIsDocSelectorOpen}
        handleSend={handleSend}
        handleAbort={handleAbort}
        handleKeyDown={handleKeyDown}
        t={t}
      />

    </div>
  );
}

