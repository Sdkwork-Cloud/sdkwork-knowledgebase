import React, { useState, useEffect } from 'react';
import { KnowledgeBaseApp, ToastContainer, TabCacheService } from '@packages/sdkwork-knowledgebase-pc-knowledgebase/src';
import { SearchModule } from '@packages/sdkwork-knowledgebase-pc-search/src';
import { useLocalStorage } from '@packages/sdkwork-knowledgebase-pc-commons/src';
import { SettingsModal } from './SettingsModal';
import { GlobalNav } from './GlobalNav';
import { UserProfileModal } from './UserProfileModal';

export function AppShell() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [themePreference, setThemePreference] = useLocalStorage<'light' | 'dark' | 'system'>('app-theme-preference', 'system');
  const [activeTab, setActiveTab] = useLocalStorage<'kb' | 'market' | 'search'>('app-active-tab', 'kb');
  const [activeColor] = useLocalStorage('app-accent-color', '#2563eb');
  const [fontSize] = useLocalStorage('app-font-size', 'normal');

  useEffect(() => {
    // Apply accent color
    document.documentElement.style.setProperty('--theme-accent', activeColor);
    
    // Apply font size
    if (fontSize === 'small') {
      document.documentElement.style.fontSize = '14px';
    } else if (fontSize === 'large') {
      document.documentElement.style.fontSize = '18px';
    } else {
      document.documentElement.style.fontSize = '16px';
    }
  }, [activeColor, fontSize]);

  useEffect(() => {
    const applyTheme = () => {
      const isDark = themePreference === 'dark' || 
        (themePreference === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };

    applyTheme();

    if (themePreference === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      mediaQuery.addEventListener('change', applyTheme);
      return () => mediaQuery.removeEventListener('change', applyTheme);
    }
  }, [themePreference]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[var(--color-kb-nav)] text-[var(--color-kb-text)] font-sans">
      <GlobalNav 
        activeTab={activeTab} 
        onTabChange={(tab) => setActiveTab(tab as 'kb' | 'market' | 'search')} 
        onOpenSettings={() => setIsSettingsOpen(true)} 
        onOpenProfile={() => setIsProfileOpen(true)}
      />
      <div className="flex-1 flex overflow-hidden relative">
        {activeTab === 'search' ? (
          <SearchModule 
            onGoToKb={(kbId) => {
              // We need to pass the selected kbId to KnowledgeBaseApp, but KnowledgeBaseApp
              // pulls from localStorage 'app-active-kb'.
              // We can set it in local storage.
              const prev = localStorage.getItem('app-active-kb');
              let newKb = null;
              if (prev && prev !== 'null') {
                 newKb = JSON.parse(prev);
                 newKb.id = kbId;
              } else {
                 newKb = { id: kbId, title: '' }; // Fallback minimally
              }
              localStorage.setItem('app-active-kb', JSON.stringify(newKb));
              window.dispatchEvent(new CustomEvent('local-storage', { detail: { key: 'app-active-kb', value: newKb } }));
              setActiveTab('kb');
            }}
            onGoToFile={(kbId, fileId) => {
              const prev = localStorage.getItem('app-active-kb');
              let newKb = null;
              if (prev && prev !== 'null') {
                 newKb = JSON.parse(prev);
                 newKb.id = kbId;
              } else {
                 newKb = { id: kbId, title: '' };
              }
              const newDoc = { id: fileId, title: 'Loading...', type: 'richtext' as any, author: '', updatedAt: new Date().toISOString() };
              TabCacheService.openDoc(kbId, newDoc);

              localStorage.setItem('app-active-kb', JSON.stringify(newKb));
              window.dispatchEvent(new CustomEvent('local-storage', { detail: { key: 'app-active-kb', value: newKb } }));
              
              setActiveTab('kb');
            }}
          />
        ) : (
          <KnowledgeBaseApp 
            activeTab={activeTab} 
            onActiveTabChange={setActiveTab as any} 
          />
        )}
      </div>

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        theme={themePreference}
        setTheme={setThemePreference}
      />
      
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />

      <ToastContainer />
    </div>
  );
}

